#---------------------------------------------------------------------------------------------
# Licensed Materials - Property of IBM 
# (C) Copyright IBM Corp. 2024 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP 
# Schedule Contract with IBM Corp.
#
# Developed by George Baklarz
#---------------------------------------------------------------------------------------------

import streamlit as st
import wxd_data as db
from streamlit import session_state as sts
from wxd_utilities import log, runOS

def getModels():
	"""
	getModels will generate a list of models that are currently found in the system.
	"""

	output = runOS("docker exec ollama ollama list")
	models = []
	first = True
	for line in output:
		if (first == True): 
			first = False
			continue
		fields = line.split(' ')
		model_name = fields[0].strip()
		if (model_name != ''):
			model_name = model_name.replace(':latest','')
			models.append(model_name)
 
	return models

def loadModel(llmname):
	"""
	loadModel will ask Ollama to load the model into the system.
	"""

	program = "loadModel"

	log(program,f"Loading model {llmname}")
	output = runOS(f"docker exec ollama ollama pull {llmname}",logit=False)
	return output

def askLLM(prompt):
	"""
	This function will call the LLM system to ask the question and retrieve the feedback from the
	model. The async function is used to print out the answer as the results come back.
	"""

	from llama_index.llms.ollama import Ollama
	import streamlit as st
	import re

	try:
		model = sts.model 
	except:
		model = 'instructlab/granite-7b-lab'
    
	llm = Ollama(base_url='http://localhost:11434',model=model, request_timeout=1000.0, streaming=True)

	content = ""
	for completion in llm.stream_complete(prompt):

		if ('runllm' in sts):
			if sts.runllm == False:
				yield content # re.sub(r"\$",r"\$",completion.delta)
				break
		content += re.sub(r"\$",r"\$",completion.delta)
		yield  re.sub(r"\$",r"\$",completion.delta)