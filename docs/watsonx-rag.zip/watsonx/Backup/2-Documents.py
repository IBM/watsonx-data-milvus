import streamlit as st
import database as db
import pandas as pd

def dataframe_with_selections(df):
    df_with_selections = df.copy()
    df_with_selections.insert(0, "Select", False)
    
        # Get dataframe row-selections from user with st.data_editor
    edited_df = st.data_editor(
                df_with_selections,
                hide_index=True,
                column_config={"Select": st.column_config.CheckboxColumn(required=True)},
                disabled=df.columns,
            )
    
        # Filter the dataframe using the temporary column, then drop the column
    selected_rows = edited_df[edited_df.Select]
    return selected_rows.drop('Select', axis=1)
                
with st.form("list_documents"):
    list_documents = '''
    # Document List

    The current documents that are stored in watsonx.data can be viewed by pressing the Documents button below.
    '''    
    st.write(list_documents)

    submitted = st.form_submit_button("List Documents")

    if submitted:

        connection = db.connectPresto()
        if (connection == None):
            st.write("Currently not connected to the database")
        else:
            df = None
            #with st.spinner("Retrieving Data"):
            df = db.runSQL(connection,"select * from iceberg_data.documents.metadata")
            selection = dataframe_with_selections(df)
            st.write("Your selection:")
            st.write(selection)

with st.form("add_document"):
    st.write("# Upload Document")
    uploaded_file = st.file_uploader("Select a file to upload")
    if uploaded_file is not None:
        st.write(f"You have a file uploaded called {uploaded_file.name}")
        
    # Every form must have a submit button.
    submitted = st.form_submit_button("Upload")
    if submitted:
        st.write("You hit submit")
