import streamlit as st
from streamlit import session_state as sts
import wxd_data as db
import pandas as pd 
import wikipedia
import wxd_wiki as wiki
from wxd_utilities import setCredentials, log

def wiki_selection():
    if ('wikidocs' in sts):
        log("wiki",sts.wikidocs['edited_rows'])
    return

st.set_page_config(
    page_title="Documents",
    page_icon=":infinity:",
    layout="wide"    
)

st.logo('/home/watsonx/Documents/watsonxdata.png')

program = "Documents"

if ('initialized' not in sts):
    if (setCredentials() == False):
        st.error("Unable to get credentials required to connect to watsonx.data.")
        log("Startup","Unable to get credentials required to connect to watsonx.data")
        st.stop()
    
connection = db.connectPresto()
if (connection == None):
    db.badConnection()
    st.stop()

st.title("Watsonx.data - Document Storage")

introduction = \
'''
This system requires that you upload documents or URLs to be used for RAG generation. There are some pre-loaded documents provided in the system that you can use for your queries. You have the option of uploading documents from your workstation (PDF, PPT, DOC, TXT) and having it catalogued in watsonx.data. You can also point to a website (URL) which will be analyzed and the contents extracted and stored in watsonx.data.
'''
st.write(introduction)
with st.expander("Technical Details"):
    details = \
"""
##### Document Storage
This screen is used to stored documents into watsonx.data. There are two Iceberg tables within watsonx.data that store
details of the documents. The first table contains document metadata:
```sql
CREATE TABLE iceberg_data.documents.metadata
    (
    "id"          int,
    "document"    varchar,
    "type"        varchar
    )
```
This simple table tracks the document name (or URL) along with the type of document. The type of document will determine
what routine will be used to extract the text from the contents.

The second table contains the data from the document.
```sql
CREATE TABLE iceberg_data.documents.rawdata
    (
    "id"          int,
    "chunk_id"    int,
    "chunk"       varchar
    )
```

The data is split into approximately 1M base64 chunks. The reason for the chunking of the data is due to a Presto client limit
of 1M messages. Once the data is stored in watsonx.data, access to the underlying object can be controlled through
user and group authentication. 

An alternate strategy would be to upload the document and store it in an S3-like bucket. The downside is that the document is exposed in the bucket rather than obsfucated in Iceberg table format.

##### Web Pages
Regular documents are stored "as-is" in watsonx.data, but URLs are handled differently. A web scraping routine extracts the text from the website and stores it in watsonx.data as a text document. What this means is that the data watsonx.data is valid as of the time the URL was uploaded. If the web page changes, it will not be reflected in the stored document. 

##### Pre-loaded Documents
There are several documents that have been pre-loaded into the system for your use. You can choose to upload your own 
documents to use with the LLMs. Some observations regarding documents.
* PDFs, DOCs, and Text create good RAG promps with a minimum of 3 sentences
* PPTs require much more time to extract text and require more sentences (>5) to generate useful RAG prompts
* URLs generate RAG prompts that may contain images or gifs that are ignored
"""
    st.markdown(details)


# Document List
                
st.header("Document list",divider=True)
description = '''
The current documents that are stored in watsonx.data are listed below. Press the Refresh button to update
the list.
'''    

st.write(description)


with st.form("Refresh", clear_on_submit=False):
    metadata = None
    with st.spinner("Retrieving Data"):
        metadata = db.runSQL(connection,"select * from iceberg_data.documents.metadata order by id desc")
        st.dataframe(metadata.sort_values(by=['id']),use_container_width=True,hide_index=True)
        
    submitted = st.form_submit_button("Refresh List")      

# Upload new document List

st.header("Upload Document or URL",divider=True)
description = '''
To upload a new document into the database, either drag or drop the document into the control below or press the Browse Files button. To upload a URL, enter the URL in the text field below. 
''' 
st.write(description)

with st.form("Upload", clear_on_submit=False):
    col1, col2 = st.columns([0.15,0.85])
    with col1:
        submitted = st.form_submit_button("Upload Doc/URL")
    with col2:
        file = st.file_uploader("Select a file to upload",label_visibility="collapsed")
        url = st.text_input("Enter a URL")
    
    if submitted and file is not None:
        okay = db.storeDocument(connection,file,type="file")
        if (okay is not None):
            db.log(program,f"File {file.name} uploaded.")   

    elif submitted and url not in [None,""]:                
        if ('HTTP' not in url.upper()):
            url = f"https://{url}"
        okay = db.storeDocument(connection,url,type="url")
        if (okay is not None):
            db.log(program,f"URL {url} uploaded.")
    elif submitted: 
        st.error("You need to supply a document or URL for me to upload!")
    else:
        pass

st.header("Upload Wikipedia Articles",divider=True)
description = '''
When you provide a Topic below, the program will query Wikipedia to find articles that best match your topic. You can select which articles to upload into the system.
''' 
st.write(description)

with st.form("Uploadwiki", clear_on_submit=False):
    col1, col2 = st.columns([0.15,0.85])
    with col1:
        submitted_search = st.form_submit_button("Get Articles",on_click=wiki_selection)
    with col2:
        topic = st.text_input("Enter a topic",label_visibility="collapsed",placeholder="Enter a topic")
    
    if submitted_search:
        if topic.strip() != "" :
            with st.spinner("Searching Wikipedia"):
                search_results = wikipedia.search(topic)
            display_articles = []
            for i in range (0,len(search_results)):
                try:
                    summary = wikipedia.summary(search_results[i])
                except Exception as err:
                    sts['articles'] = None
                    continue

                display_articles.append([False,search_results[i],summary])

            sts['articles'] = display_articles

            df = pd.DataFrame(display_articles,columns=['Selected','Title','Summary'])

            # event = st.data_editor(
            #     df,
            #     on_change=wiki_selection,
            #     selection_mode='multi-row',
            #     use_container_width=True,
            #     hide_index=True,
            #     key='wikilist'
            #     )

           
            wikilist = st.data_editor(df,
                column_config={
                "selected": st.column_config.CheckboxColumn("Selected"),
                "topic"   : st.column_config.TextColumn("Topic"),
                "summary" : st.column_config.TextColumn("Summary")
                },
                disabled=["topic","summary"],
                key="wikidocs",
                # on_change=wiki_selection,
                hide_index=True
            )

            # sts['wikilist'] = wikilist

upload_wiki = st.button("Upload Wiki Articles")
if upload_wiki:
    st.write(sts['results'])
    if "articles" not in sts:
        st.error("No articles were found to load")
    elif "selected" not in sts:
        st.error("No articles were selected to load")
    elif len(sts.selected) == 0:
        st.error("No articles were selected to load")
    else:
        log(program,f"Selection={sts.selected}")