#---------------------------------------------------------------------------------------------
# Licensed Materials - Property of IBM 
# (C) Copyright IBM Corp. 2024 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP 
# Schedule Contract with IBM Corp.
#
# Developed by George Baklarz
#---------------------------------------------------------------------------------------------
#
#   Milvus routines
#
#   loadvectors - Given a list of document IDs, load the documents in as vectors into Milvus
#   querymilvus - Given a string, retrieve the vectors from Milvus that best match
#

import warnings
import wxd_data as db
import streamlit as st
from wxd_utilities import log
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
from pymilvus import utility, Milvus, IndexType, Status, connections, FieldSchema, DataType, Collection, CollectionSchema
from streamlit import session_state as sts


def loadVectors(_connection, ids):
    """
    Given a text document, split the text into chunks and then load them into
    Milvus. After the load is completed, return the collection that can be
    used for queries.
    """
  
    program = "loadVectors"

    host            = sts['mivlus_host']    
    port            = sts['milvus_port']    
    user            = sts['milvus_user']    
    password        = sts['milvus_password']
    server_pem_path = sts['server_pem_path']

    document = None
    for id in ids:
        if (document == None):
            document = db.getDocument(_connection, id)
        else: 
            nextdoc  = db.getDocument(_connection, id)
            document = f"{document}\n{nextdoc}"

    if (document in [None,""]):
        log(program,"Error extracting the document")
        return None

    with st.status(f"Extracting document", expanded=True, state="running") as status:
        
        status.update(label="Connecting to Milvus", state="running")

        connections.connect(alias='default',
                        host=host,
                        port=port,
                        user=user,
                        password=password,
                        server_pem_path=server_pem_path,
                        server_name='watsonxdata',
                        secure=True)

        program = "loadVectors"
        title = "Document"

        log(program,f"Loading document with length={len(document)}")
        
        warnings.filterwarnings('ignore')
        
        status.update(label="Splitting text", state="running")
        chunk_size = 1024 # 1024
        chunk_overlap = 0
        try:
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap) 
            docs = text_splitter.create_documents([document])
        except Exception as e:
            status.update(label="Vector loading error. Check the log for details", state="error", expanded=False)	
            log(program,"Error in Text Splitter")
            log(program,f"{repr(e)}")
            return None
        
        status.update(label="Creating passages", state="running")
        passages = []
        passage_titles = []
        for doc in docs:
            passages.append(doc.page_content)
            passage_titles.append(title)
        
        status.update(label="Dropping collection", state="running")
        utility.drop_collection("documents")
        
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True), # Primary key
            FieldSchema(name="article_title", dtype=DataType.VARCHAR, max_length=255,),
            FieldSchema(name="article_text", dtype=DataType.VARCHAR, max_length=2500,),
            FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=384),
        ]
        
        schema = CollectionSchema(fields, "Documents")
        
        collection = Collection("documents", schema)
        
        # Create index
        index_params = {
                'metric_type':'L2',
                'index_type':"IVF_FLAT", #IVF_FLAT
                'params':{"nlist":2048}
        }

        status.update(label="Creating index", state="running")   
        try:
            collection.create_index(field_name="vector", index_params=index_params)
        except Exception as e:
            status.update(label="Vector loading error. Check the log for details", state="error", expanded=False)	           
            log(program,"Error in Index Creation")
            log(program,f"{repr(e)}")
            return None


        # Create vector embeddings + data
        status.update(label="Sentence transformer", state="running")
        try:
            model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2') # 384 dim
            passage_embeddings = model.encode(passages)
        except Exception as e:
            status.update(label="Vector loading error. Check the log for details", state="error", expanded=False)	           
            log(program,"Error in Sentence Transformer")
            log(program,f"{repr(e)}")
            return None    
        
        basic_collection = Collection("documents") 
        data = [
            passage_titles,        
            passages,
            passage_embeddings
        ]

        status.update(label="Loading vectors", state="running")
        try:

            out = basic_collection.insert(data)
            basic_collection.flush()  # Ensures data persistence
            basic_collection = Collection("documents") 
            basic_collection.load()
        except Exception as e:
            status.update(label="Vector loading error. Check the log for details", state="error", expanded=False)	          
            log(program,"Error in Vector load step.")
            log(program,f"{repr(e)}")
            return None

        status.update(label="Vector loading complete", state="complete", expanded=False)	
 
    log(program,f"Loading complete")        
    return basic_collection 

def query_milvus(query, collection, max_results):
    """
    Given a query, convert the text into a vector and then look for similar text chunks in the document(s) 
    that you vectorized. The max_results field determines how many sentences are returned.
    """

    from sentence_transformers import SentenceTransformer
    from wxd_utilities import log
    import pandas

    program = "query_milvus"

    # max_results = collection.num_entities
    
    model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2') # 384 dim
    query_embeddings = model.encode([query])

    # Search
    search_params = {
        "metric_type": "L2", 
        "params": {"nprobe": 5}
    }
    results = collection.search(
        data=query_embeddings, 
        anns_field="vector", 
        param=search_params,
        limit=max_results,
        expr=None, 
        output_fields=['article_text'],
    )

    distances = []
    text = []

    for i in range(0,len(results[0])):
        distances.append(results[0][i].distance)
        text.append(results[0][i].entity.get('article_text'))
    
    df = pandas.DataFrame(zip(distances,text),columns=['distance','text']).sort_values(by=['distance'])

    log(program,f"Milvus query - records returned = {len(df)}")
    
    return df

def createPrompt(prompt, terse, results):
    """
    Given a question (prompt), generate the sentence that will be provided to the LLM.
    """

    import re
    from wxd_utilities import log

    program = 'createPrompt'

    relevant_chunks  = []
    #found = 0

    for _, row in results.iterrows():
        relevant_chunks.append(re.sub(r"^.*?\. (.*\.).*$",r"\1",row['text']))

    if (len(relevant_chunks) == 0):
        log(program,f"No sentences were found to create a RAG prompt.")
        return None
    else:
        log(program,f"RAG generated with {len(relevant_chunks)} sentences")
        
    
    data = "\n\n".join(relevant_chunks)

    # if terse:
    #     question = f"Using this data: \n\n{data}. \n\nProvide a concise response to this prompt: {prompt}"
    # else:
    #     question = f"Using this data: \n\n{data}. \n\nRespond to this prompt: {prompt}"
    header = """Answer the question based on the context below. If the question cannot be answered using the information provided answer with "I don't know"."""

    if terse:
        question = f"{header}\n\nContext:\n\n{data}.\n\nQuestion: Provide a concise response to {prompt}"
    else:
        question = f"{header}\n\nContext:\n\n{data}.\n\nQuestion: {prompt}"

    return question
