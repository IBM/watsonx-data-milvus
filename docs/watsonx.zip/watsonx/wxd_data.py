#---------------------------------------------------------------------------------------------
# Licensed Materials - Property of IBM 
# (C) Copyright IBM Corp. 2024 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP 
# Schedule Contract with IBM Corp.
#
# Developed by George Baklarz
#---------------------------------------------------------------------------------------------
#
#	This code contains routines that are used to store, retrieve, and manipulate documents in
#	watsonx.data
#

import streamlit as st
from streamlit import session_state as sts
from wxd_minio import resetMinio
from wxd_utilities import log

def connectPresto():
	"""
	connectPresto is used to connect to Presto engine that is running in the watsonx.data system. The
	credentials are hardcoded for the watsonx.data developer edition system.
	"""

	import prestodb
	from prestodb import transaction
	import pandas as pd
	import sqlalchemy
	from sqlalchemy import create_engine
	import warnings
	warnings.filterwarnings("ignore")

	program = "connectPresto"

	# Connection Parameters

	userid     = sts['presto_userid']  
	password   = sts['presto_password']
	hostname   = sts['presto_host']    
	port       = sts['presto_port']    
	catalog    = sts['presto_catalog'] 
	schema     = sts['presto_schema']  
	certfile   = sts['presto_certfile']	

	# Connect Statement
	try:
		connection = prestodb.dbapi.connect(
				host=hostname,
				port=port,
				user=userid,
				catalog=catalog,
				schema=schema,
				http_scheme='https',
				auth=prestodb.auth.BasicAuthentication(userid, password)
		)
		if (certfile != None):
			connection._http_session.verify = certfile

		log(program,f"Successful connection")

	except Exception as e:
		log(program,f"Connection failed: {repr(e)}")
		connection = None

	return(connection)

def runSQL(_connection, sql):
	"""
	runSQL will run the sql command and return a Panda dataframe as the output. If the SQL fails, the 
	error is logged and the program returns an empty dataframe.
	"""
	import pandas as pd

	program = "runSQL"
	log(program,sql[:80])

	# The df contains the answer set in a Pandas dataframe
	try:
		df = pd.read_sql(sql,_connection)
		log(program,f"SQL completed. Row count = {len(df)}")
	except Exception as e:
		df = pd.DataFrame()
		log(program,f"SQL failed: {repr(e)}")

	return df
	
def runDML(_connection, sql):
	"""
	runDML is used for excuting SQL statements such as table creation, insert statements, etc... that 
	do not return a value. 
	"""
	program = "runDML"
	log(program,sql[:80])

	cursor = _connection.cursor()

	try:
		cursor.execute(sql)
		cursor.close()
		log(program,"SQL completed.")
		return True
	except Exception as err:
		log(program,f"SQL failed: {repr(err)}")
		return False
	
def insertMetadata(_connection, document, type="file"):
	"""
	Insert the document details into the control table. The value that
	is returned is the document ID that was created.
	"""
	
	import os
	import base64

	program = "insertMetadata"

	# Check the data

	if (document in [None,""]):
		return None

	# Retrieve last document number in the table
	
	sql = "select max(id) as last from iceberg_data.documents.metadata"
	count = runSQL(_connection, sql)
	count = count['last'][0]
	if (count in [None, ""]):
		id = 1
	else:
		id = int(count) + 1    

	# Get the filename (if there is one)
	if (type == "url"):
		filename = document
		type = "html"
	elif (type == "wiki"):
		filename = document
		type = "wiki"
	else:
		raw_filename = document.name
		filename = os.path.basename(raw_filename)
		head, tail = os.path.splitext(raw_filename)
		type = tail.replace(".","").lower()
		filename = f"{head}.{type}"
	
	sql = f"insert into iceberg_data.documents.metadata values ({id},'{filename}','{type}')"
	rc = runDML(_connection, sql)
	
	return id

def badConnection():
	"""
	We can't connect to the database so we need issue this message.
	"""

	st.header("Oops! Something has gone wrong!")
	error = \
"""
I can't connect to the watsonx.data service!
Check the following:
* In your reservation, click on the watsonx.data UI link
   * If you cannot connect, the service is down or unavailable
   * Press the Diagnostics button below and choose the Restart Server option
* If you can connect to the watsonx.data UI, log into the service as ibmlhadmin / password
   * Use the Data Manager view and check the schemas under the iceberg_data catalog
   * Three tables should exists - metadata, rawdata, and questions
   * If the tables do not exists, press the Diagnostics button below and choose the Rebuild Database option
* If all else fails, request another image.
"""
	st.error(error)
	if st.button("Diagnostics"):
		st.switch_page("pages/7-Diagnostics.py")
	return

def rebuildDatabase(_connection):
	"""
	Rebuild the contents of the database.
	"""

	program = "rebuildDB"

	if (_connection == None):
		error = \
"""
I can't connect to the watsonx.data service!
Check the following:
* In your reservation, click on the watsonx.data UI link
   * If you cannot connect, the service is down or unavailable
   * Press the Troubleshooting button and choose the Restart Server option
* If you can connect to the watsonx.data UI, log into the service as ibmlhadmin / password
   * Use the Data Manager view and check to see if you can view ANY schemas
   * If you can view the schemas then this program has an issue and you need to report it
   * If you cannot view any schema then the Presto engine may be down or restarting
   * Try pressing the Recreate Database button again and if it fails then you may want to 
	 restart the server.
"""
		st.error(error)
		log(program,"Can't connect to watsonx.data.")
		return False
	
	if ('initialized' not in sts):
		st.error("The system variables have not been initialized.")
		log(program,"The system variables and passwords have not been initialized.")
		return False
	
	schema = sts["minio_bucket"]
	
	sql = f"DROP TABLE IF EXISTS iceberg_data.{schema}.metadata"
	if (runDML(_connection, sql) == False):
		return False
	sql = f"DROP TABLE IF EXISTS iceberg_data.{schema}.rawdata"
	if (runDML(_connection, sql) == False):
		return False
	sql = f"DROP TABLE IF EXISTS iceberg_data.{schema}.questions"
	if (runDML(_connection, sql) == False):
		return False
	sql = f"DROP SCHEMA IF EXISTS iceberg_data.{schema}"
	if (runDML(_connection, sql) == False):
		return False

	if (resetMinio() == False):
		st.error("Unable to create bucket")
		return False
	
	sql = f"""
		CREATE SCHEMA IF NOT EXISTS 
			iceberg_data.documents
		WITH ( location = 's3a://iceberg-bucket/{schema}')
		"""
	if (runDML(_connection, sql) == False):
		return False
	sql = f"""
		CREATE TABLE iceberg_data.{schema}.metadata
			(
			"id"          int,
			"document"    varchar,
			"type"        varchar
			)
		  """
	if (runDML(_connection,sql) == False):
		return False
	sql = f"""
		CREATE TABLE iceberg_data.{schema}.rawdata
		(
		"id"          int,
		"chunk_id"    int,
		"chunk"       varchar
		)
		"""
	if (runDML(_connection,sql) == False):
		return False
	sql = f"""
		CREATE TABLE iceberg_data.{schema}.questions
		(
		"id"          int,
		"question"    varchar
		)
		"""
	if (runDML(_connection,sql) == False):
		return False

def storeDocument(_connection, uri, type="file",contents=None):
	"""
	The document that is provided is read and broken up into chunks that
	are then inserted into watsonx.data in the rawdata control table. The document ID 
	is passed to the procedure to provide the unique identifier for the chunks. The return
	value is the number of chunks generated.
	"""
								
	from base64 import urlsafe_b64encode, urlsafe_b64decode
	from llama_index.readers.web import SimpleWebPageReader

	chunk_size=750000

	program = "storeDocument"

	schema = sts["minio_bucket"]	

	if (type == "url"):
		rawdata = ""
		try:
			documents = SimpleWebPageReader(html_to_text=True).load_data([uri])
		except Exception as e:
			log(program,f"The URL {uri} was invalid or could not be reached.")
			log(program,f"{repr(e)}")
			return None		

	id = insertMetadata(_connection,uri,type=type)
	if (id in [None,"",0]):
		log(program,f"Unable to retrieve a document ID.")
		return None

	if (uri in [None,""]):
		log(program,f"The document is empty.")
		return None
	
	sql = f"select count(*) as total from iceberg_data.{schema}.rawdata where id = {id}"
	count = runSQL(_connection, sql)
	count = count['total'][0]

	try:
		count = int(count)
		if (count != 0):
			found = True
		else:
			found = False
	except:
		found = False

	if (found == True):
		log(program,f"The document ID {id} already has the document stored in the database.")
		return None

	if (type == "url"):
		
		for doc in documents: # iterate the document pages
			if (rawdata == None):
				rawdata = doc.text
			else:
				rawdata += doc.text

		if (rawdata == ""):
			log(program,f"The URL {uri} was invalid or could not be reached.")
			return None
		
		rawdata = rawdata.encode(encoding='utf-8')

	elif (type == "wiki"):

		rawdata = contents
		rawdata = rawdata.encode(encoding='utf-8')
		
	else:
		rawdata = uri.getvalue() # open(document,"rb").read()
		
	encoded = urlsafe_b64encode(rawdata)

	file_size = len(encoded)
	total_chunk = (file_size // chunk_size) + 1

	pos = 0
	chunk_id = 0
	while pos <= len(encoded):
		chunk_id += 1
		chunk = encoded[pos:pos+chunk_size].decode('utf-8')
		sql = f"insert into iceberg_data.{schema}.rawdata values ({id}, {chunk_id}, '{chunk}')"
		okay = runDML(_connection,sql)
		pos += chunk_size

	return chunk_id    

def getDocument(_connection,id):
	"""
	The document with the provided id is retrieved and recombined to create the 
	original document. The document name provided will be overwritten by the contents
	of the database. The return value is either None (error) or the text of the 
	document.
	"""

	from base64 import urlsafe_b64encode, urlsafe_b64decode
	from llama_index.core.text_splitter import SentenceSplitter
	from llama_index.core import SimpleDirectoryReader
	import re 

	program = "getDocument"

	if ('initialized' not in sts):
		st.error("The system variables have not been initialized.")
		log(program,"The system variables and passwords have not been initialized.")
		return False
	
	schema = sts["minio_bucket"]	

	with st.status(f"Retrieving Document", expanded=True, state="running") as status:

		# Check the data
		if (id in [None,"",0]):
			status.update(label="Document retrieval failed. Check the log for details", state="error", expanded=False)			
			log(program,f"An invalid document ID {id} was passed to the program.")
			return None

		sql = f"select document, type from iceberg_data.{schema}.metadata where id = {id}"
		results = runSQL(_connection,sql)

		if (results.empty == True):
			status.update(label="SQL statement failure. Check the log for details", state="error", expanded=False)			
			log(program,f"SQL Error or Document ID {id} was not found.")
			return None

		document = results['document'][0]
		doctype  = results['type'][0]

		if (document in [None,""] or doctype in [None,""]):
			status.update(label="Document not found. Check the log for details", state="error", expanded=False)			
			log(program,f"SQL Error or Document ID {id} was not found.")
			return None			

		if (doctype == "html"):
			filename = "webpage.txt"
		else:		
			filename = document

		sql = f"select chunk_id, chunk from iceberg_data.{schema}.rawdata where id = {id} order by chunk_id asc"
		status.update(label=f"Retrieving Document {document}",state="running",expanded=True)
		
		chunks = runSQL(_connection,sql)
			
		if (len(chunks) == 0):
			status.update(label=f"The document ID {id} has no data in the control table.",state="error",expanded=False)
			log(program,f"Document ID {id} has no data.")
			return None

		targetDocument = f"/tmp/{filename}"
		reconstituted = None
		chunklist = chunks['chunk'].tolist()

		status.update(label=f"Combining Document",state="running",expanded=True)
		reconstituted = ''.join(chunklist)

		try:
			with open(targetDocument,"wb") as fd:
				rawchunk = urlsafe_b64decode(reconstituted)
				fd.write(rawchunk)
		except Exception as e:
			status.update(label=f"Failed to write document. See log for details.",state="error",expanded=False)
			log(program,f"Error writing data to file {targetDocument}")
			log(program,f"{repr(e)}")
			return None

		status.update(label=f"Analyzing document {document} (This takes some time)",state="running",expanded=True)
		try:
			documents = SimpleDirectoryReader(input_files=[targetDocument]).load_data()
		except Exception as e:
			status.update(label=f"Failed to process document. See log for details.",state="error",expanded=False)
			log(program,f"Unable to process the file")
			log(program,f"{repr(e)}")	
			return None

		status.update(label=f"Fixing document",state="running",expanded=True)
		returntext = None
		for doc in documents: # iterate the document pages
			if (returntext == None):
				returntext = doc.text
			else:
				returntext += doc.text

		clean1 = ''.join([i if ord(i) < 128 else ' ' for i in returntext])
		clean2 = " ".join(clean1.split())
		clean3 = clean2.replace("\n","")
		clean4 = re.sub(r" ([s]) ",r"\1 ",clean3)
		clean5 = re.sub(r" ([b-hj-z]) ",r" \1",clean4)
		clean6 = re.sub(r'http\S+', ' ', clean5)
		returntext = re.sub(r"\$",r"\$",clean6)

	status.update(label=f"Document extracted",state="complete",expanded=False)	

	return returntext