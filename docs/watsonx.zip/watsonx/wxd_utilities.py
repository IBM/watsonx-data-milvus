#---------------------------------------------------------------------------------------------
# Licensed Materials - Property of IBM 
# (C) Copyright IBM Corp. 2024 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP 
# Schedule Contract with IBM Corp.
#
# Developed by George Baklarz
#---------------------------------------------------------------------------------------------
#	
#	Utility Code
#
#	This code contains several utility routines used by the system.
#

import streamlit as st
import hmac
from streamlit import session_state as sts

def runOS(command,logit=True):
	"""
	runOS takes a bash command and executes in the current environment. The results are split by
	newline and returned back to the program as an array of lines. If there is a failure in executing the 
	code, the details of the error are placed into the log file and no output is returned.
	"""
	import subprocess

	program = "runOS"

	success = False

	try:
		output = subprocess.check_output(command, shell=True, text=True, stderr=subprocess.STDOUT)
		success = True 
	except subprocess.CalledProcessError as e:
		output = e.output
		log(program,f"[1] Execution of command failed: {command}")
		if logit: 
			log(program,f"[1] {output}")
	except Exception as e:
		log(program,f"[2] Execution of command failed: {command}")
		if logit:
			log(program,f"[2] {repr(e)}")

	if (success == True):
		results = output.split('\n')
		output = []
		for result in results:
			if (result.strip() != ""):
				output.append(result)
		log(program,f"Command: {command}")
		if logit:
			for line in output:
				if (line.strip() != ""):
					log("Output",line)
	else:
		output = None

	return output

def checkStatus():
	"""
	checkStatus runs the watsonx.data status command and returns the list of running processes as an 
	array. Note that the program has a list of default programs that run in a watsonx.data environment and
	so it checks to make sure that these systems are running. The value that is returned is an array of 
	values with the service name and the status. The status can be unknown (we didn't find it in the list of running
	services), or it is the status that is returned by the watsonx.data command.
	"""

	import subprocess
	watsonx = {
		"ibm-lh-cpg"               : "Unknown",
		"ibm-lh-etcd"              : "Unknown",
		"ibm-lh-hive-metastore"    : "Unknown",
		"ibm-lh-milvus"            : "Unknown",
		"ibm-lh-minio"             : "Unknown",
		"ibm-lh-postgres"          : "Unknown",
		"ibm-lh-presto"            : "Unknown",
		"ibm-lh-validator"         : "Unknown",
		"lhconsole-api"            : "Unknown",
		"lhconsole-nodeclient-svc" : "Unknown",
		"lhconsole-ui"             : "Unknown",
	}

	status_list = runOS('sudo /root/ibm-lh-dev/bin/status --all')
	for service in status_list:
		if (service in [None,""]): continue
		service = service.replace("\t"," ")
		service = service.replace(",","")
		service = service.replace("0.0.0.0:","")
		items = service.split()
		if (items[0] == "Checking"): continue
		service = items[0].strip()
		status = items[1].strip()
		if (service in watsonx):
			watsonx[service] = status.title()

	return watsonx

def log(program,text):
	"""
	The log function will write the text into a log file that can be used for diagnostics. The log
	file is erased when this system initially starts so that the log file is valid for the current
	session only. The log file can be found at /tmp/watsonx.log.
	"""

	import datetime

	if (text not in [None,""] and program not in [None,""]):
		with open("/tmp/watsonx.log","a") as fd:
			today = datetime.datetime.now().strftime("%y-%m-%d %H:%M:%S")
			fd.write(f"{today},{program},`{text}`\n")

	return

def setCredentials():
	"""
	setCredentials is used to set the credentials for the watsonx.data system. Each of the settings 
	are placed into the streamlit service so that the values are available across the web pages. Normally you
	would use either global variables or classes to contain the values, but due to the way that streamlit works,
	the safest way to keep the values is by using the builtin session state.
	"""

	import streamlit as st
	import warnings, os
	warnings.filterwarnings('ignore')

	sts['version']         = '1.0.2'
	sts['initialized']     = False
	sts['minio_host']      = "watsonxdata"
	sts['minio_port']      = "9000"
	sts['minio_bucket']	   = 'documents'
	sts['hive_host']       = "watsonxdata"
	sts['hive_port']       = "9083"
	sts['presto_userid']   = 'ibmlhadmin'
	sts['presto_password'] = 'password'
	sts['presto_host']     = 'watsonxdata'
	sts['presto_port']     = '8443'
	sts['presto_catalog']  = 'tpch'
	sts['presto_schema']   = 'tiny'
	sts['presto_certfile'] = "/certs/lh-ssl-ts.crt"	
	sts['rag']             = True
	sts['terse']           = True
	sts['displayrag']      = True
	sts['vectorized']      = False
	sts['mivlus_host']     = 'watsonxdata'
	sts['milvus_port']     = 19530
	sts['milvus_user']     = 'ibmlhadmin'
	sts['milvus_password'] = 'password'
	sts['server_pem_path'] = "/certs/lh-ssl-ts.crt" # '/tmp/presto.crt'
	sts['model']           = "instructlab/granite-7b-lab"
	sts['queries']         = []
	sts['max_sentences']   = 3


	hive_id           = None
	hive_password     = None
	minio_access_key  = None
	minio_secret_key  = None
	keystore_password = None	

	try:
		with open('/certs/passwords') as fd:
			certs = fd.readlines()
		for line in certs:
			args = line.split()
			if (len(args) >= 3):
				system   = args[0].strip()
				user     = args[1].strip()
				password = args[2].strip()
				if (system == "Minio"):
					minio_access_key = user
					minio_secret_key = password
				elif (system == "Thrift"):
					hive_id = user
					hive_password = password
				elif (system == "Keystore"):
					keystore_password = password
				else:
					pass
	except Exception as e:
		st.error("Certificate file with passwords could not be found")
		return False	
	
	sts['hive_id']           = hive_id           
	sts['hive_password']     = hive_password     
	sts['minio_access_key']  = minio_access_key  
	sts['minio_secret_key']  = minio_secret_key  
	sts['keystore_password'] = keystore_password 
	sts['initialized']       = True

	return True

def check_password():
	"""
	Returns `True` if the user had a correct password.
	"""

	def login_form():
		"""Form with widgets to collect user information"""
		col1, col2 = st.columns([0.5,0.5])
		with col1:
			with st.form("Credentials"):
				text = \
"""
##### IBM watsonx.data and Milvus RAG Demonstration
Enter you credentials below.
"""
				st.markdown(text)
				st.text_input("Username", key="username")
				st.text_input("Password", type="password", key="password")
				st.form_submit_button("Log in", on_click=password_entered)

	def password_entered():
		"""Checks whether a password entered by the user is correct."""
		if st.session_state["username"] in st.secrets[
			"passwords"
		] and hmac.compare_digest(
			st.session_state["password"],
			st.secrets.passwords[st.session_state["username"]],
		):
			st.session_state["password_ok"] = True
			del st.session_state["password"]  # Don't store the username or password.
			del st.session_state["username"]
		else:
			st.session_state["password_ok"] = False

	# Return True if the username + password is validated.
	if st.session_state.get("password_ok", False):
		return True

	# Show inputs for username + password.
	login_form()
	if "password_ok" in st.session_state:
		st.error("User not known or password incorrect")
	return False