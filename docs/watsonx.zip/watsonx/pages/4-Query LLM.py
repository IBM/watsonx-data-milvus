#---------------------------------------------------------------------------------------------
# Licensed Materials - Property of IBM 
# (C) Copyright IBM Corp. 2024 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP 
# Schedule Contract with IBM Corp.
#
# Developed by George Baklarz
#---------------------------------------------------------------------------------------------
#
# Query LLM Panel
#

import streamlit as st
import pandas as pd
from streamlit import session_state as sts
from wxd_milvus import query_milvus, createPrompt, listCollections
from wxd_utilities import log, runOS, setCredentials, check_password
from wxd_ollama import getLLMs, askLLM

def add_prompt(prompt):
    """
    Place a prompt into the saved queries array for future retrieval
    """

    log("prompt",prompt)
    if (prompt not in [None, ""]):
        if ("queries" in sts):
            if (prompt not in sts.queries):
                sts.queries.append(prompt)

@st.fragment()
def collection_select():
    collection_list = listCollections()
    collection_list.sort()        
    col_name = st.selectbox("Collections", collection_list, index=0,label_visibility="collapsed",placeholder="Current Collection")
    if (col_name not in [None, ""]):
        sts.collection_name = col_name 
        sts.collection_index = collection_list.index(sts.collection_name)

st.set_page_config(
    page_title="Chat",
    page_icon=":infinity:",
    layout="wide"
)                

if not check_password():
    st.stop()

if ('initialized' not in sts):
    if (setCredentials() == False):
        st.error("Unable to get credentials required to connect to watsonx.data.")
        log("Startup","[1] Unable to get credentials required to connect to watsonx.data")
        st.stop()

st.logo('/home/watsonx/Documents/watsonxdata.png')

program = "Chat"

st.header("Query LLM",divider=True)

introduction = \
'''
Enter your questions below and wait for the response from the LLM. Note that this system does not have GPUs attached to it so the response may take a minute or so to return. Update these settings on the left side to adjust the text provided to the LLM.
'''

st.write(introduction)

if (sts.model == None):
    st.error("A model needs to be loaded into the system before you attempt to begin a chat session. Please use the LLM Models screen to upload a model to use.")
    st.stop()

with st.popover("Technical Details"):
    details = \
"""
##### LLM Query
This dialog is used to query the LLM using a set of parameters to modify the original prompt. 

The LLM parameters on the left side of the screen provides an opportunity to adjust which LLM to use when requesting a response as well as limit the number of sentences that the RAG process generates.

##### LLM Settings

The LLM table provides a list of LLMs that are currently loaded into the system. Choose which LLM you want to use to answer your query. The default LLM is the Instructlab/granite-7b-lab model.

Use the Clear button to clear the history of questions and LLM responses. If you find that the LLM is taking too long to respond (or saying too much), press the Stop LLM button. Note that stopping the LLM will clear the response on the screen.

#### Collections
The list of collections that have been vectorized are found in this table. Select which collection you want to use when generating the RAG prompt.

##### Settings
The RAG prompt button will tell the program to generate a RAG response. If this is turned off, the question is sent "as is" to the LLM. This provides an opportunity to see what the LLM answer will be without a RAG prompt. Turning on the RAG prompt and then asking the same question will demonstrate how the RAG prompt can help the LLM generate a better answer. 

The Display RAG button will include the complete RAG prompt on the screen. If you want to hide the RAG prompt, turn the display RAG button off.

The Concise response button will tell the LLM to limit the answer to your question. If you turn Concise output off, the LLM will be allowed to answer your question without length restrictions. The tradeoff when turning off the concise option is the amount of time it takes to return the full output from the LLM. 

The minimum sentences slider is used to limit the number of sentences that the RAG program will use in the question. The default number is 3 sentences. Using a larger number of sentences will slow down the LLM response but may result in a higher quality answer.

#### Questions
The left sidebar includes a list of questions previously sent to the LLM. To copy a question into the LLM prompt, use the following steps:
1. Click on the question you want to copy from the list (it will be highlighted)
2. Use the keyboard copy button (Windows/Linux &#8963;&#8211;c, Mac &#8984;&#8211;c) to place the value into the clipboard
3. Click on the LLM question input line
4. Use keyboard paste button (Windows/Linux &#8963;&#8211;v, Mac &#8984;&#8211;v) to place the copied value into the line

##### Application Logic
The process which takes place when you enter a question is:
* The question is turned into a vector value
* The value is compared to the sentence vectors that were generated in the Vectorize Document step
* The 3 best sentences (or whatever you may have set the sentence limit to) will be used to generate a RAG prompt
* The RAG prompt is sent to the LLM
* The program displays the results as they are generated by the LLM

Note that this system does not have GPUs available to it. This means that the response from the LLM could be in the order of minutes so you will need some patience! If you think you have seen enough output, press the STOP button.

If you want to view the Milvus vector distance for the RAG prompts, view the LOG file output.
"""
    st.markdown(details)

st.subheader("Chat",divider=True)

with st.sidebar:

    col1, col2  = st.columns([0.95,0.05])
    st.markdown("""
        <style>
        [data-testid=column]:nth-of-type(1) [data-testid=stVerticalBlock]{
            gap:5px ;
        }
        </style>
        """,unsafe_allow_html=True)
    with col1:
        llmnames = getLLMs()
        index = llmnames.index(sts.model)
        st.markdown("##### Current LLM Model")        
        selected_model = st.selectbox("LLM Models", llmnames, index=index,label_visibility="collapsed",placeholder="Current LLM Model")
        if (selected_model not in [None, ""]):
            sts.model = selected_model
        if st.button("Clear conversation"):
            sts.messages = []
        if st.button("Stop LLM Response"):
            sts.runLLM = False

        st.html('<hr style="margin-top: 5px; margin-bottom: 5px; border-color: Black;"/>') 
        st.markdown("##### Current Document Collection")
        collection_select()

        st.html('<hr style="margin-top: 5px; margin-bottom: 5px; border-color: Black;"/>')                
        st.markdown("##### Prompt Settings")       
        previous_prompt = None
        sts.rag = st.toggle("Use RAG Prompt",value=sts.rag,key="rag_setting")
 
        sts.displayrag = st.toggle("Display RAG Prompt",value=sts.displayrag,key="rag_display")
        sts.terse = st.toggle("Concise Response",value=sts.terse,key="terse_setting")
        st.markdown("##### Maximum RAG sentences")
        sts.max_sentences = st.slider("Maximum RAG sentences",1,9,label_visibility="collapsed",value=sts.max_sentences)

        df = pd.DataFrame(sts.queries,columns=['Questions']).sort_values(by=['Questions'])
        st.html('<hr style="margin-top: 5px; margin-bottom: 5px; border-color: Black;"/>')           
        st.markdown("##### Questions")
        st.dataframe(df,hide_index=True,selection_mode="single-column",use_container_width=True)

if "messages" not in sts:
    sts.messages = []

# Display chat messages from history on app rerun
for message in sts.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

# Accept user input

if prompt := st.chat_input(placeholder="Enter your question"):
    sts.runllm = True
    add_prompt(prompt)
    with st.chat_message("user"):
        if (sts.rag == False):
            if sts.terse:
                llm_prompt = f"Provide a concise response to this prompt: {prompt}"
            else:
                llm_prompt = prompt

            if sts.displayrag:
                display_prompt = llm_prompt
            else:
                display_prompt = prompt
            sts.messages.append({"role": "user", "content": display_prompt})

        else:

            sentences = query_milvus(prompt,sts.collection_name,sts.max_sentences)
            llm_prompt = createPrompt(prompt,sts.terse,sentences)
            if (llm_prompt == None):
                st.error("Unable to create a prompt based on the document that was provided.")
                log(program,"[1] Unable to create a prompt based on the document that was provided.")
            if sts.displayrag:
                display_prompt = llm_prompt
            else:
                display_prompt = prompt                
            sts.messages.append({"role": "user", "content": display_prompt})

        st.write(display_prompt)

    # Display assistant response in chat message container

    with st.chat_message("assistant"):
        with st.status(f"LLM: {sts.model} is processing...", expanded=True, state="running") as status:
            answer = st.write_stream(askLLM(llm_prompt))
            status.update(label="Answered", state="complete")
            sts.messages.append({"role": "assistant", "content": answer})

        st.rerun()
