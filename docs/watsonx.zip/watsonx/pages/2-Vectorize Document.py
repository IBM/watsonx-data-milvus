#---------------------------------------------------------------------------------------------
# Licensed Materials - Property of IBM 
# (C) Copyright IBM Corp. 2024 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP 
# Schedule Contract with IBM Corp.
#
# Developed by George Baklarz
#---------------------------------------------------------------------------------------------
#
# Vectorize documents panel
#

import streamlit as st
import wxd_data as db
import wxd_milvus as wxd_milvus
from streamlit import session_state as sts
from wxd_utilities import setCredentials, log, check_password

st.set_page_config(
    page_title="Prompts",
    page_icon=":infinity:",
    layout="wide"
)

st.logo('/home/watsonx/Documents/watsonxdata.png')

if not check_password():
    st.stop()

if ('initialized' not in sts):
    if (setCredentials() == False):
        st.error("Unable to get credentials required to connect to watsonx.data.")
        log("Startup","Unable to get credentials required to connect to watsonx.data")
        st.stop()

connection = db.connectPresto()
if (connection == None):
    db.badConnection()
    st.stop()

program = "Prompts"

st.title("Milvus - Vector Storage")
description = """
The Milvus vector database is used to store sentences extracted from documents, and then converted into vectors for searching. Choose one or more documents from the uploaded files to have them stored into Milvus and vectorized for use in RAG genereation on the LLM screen.
"""
st.write(description)

with st.popover("Technical Details"):
    details = \
"""
##### Vectorize Documents
In order to create a RAG (Retrieval Augmented Generation), one or more documents must be selected from the database, the text
extracted, and then stored into Milvus and vectorized.

The process to vectorize a document involves converting the document (PPT, PDF, etc...) into RAW text. Once the text
is available, the text is split into smaller chunks, with each chunk containing 250 or so words. These chunks are stored
in a Milvus database and the text is vectorized using an algorithm (sentence-transformers/all-MiniLM-L6-v2).

Once the vectorization is completed, we can use search the data for similar sentences when generating a RAG prompt.

The LLM can run without vectorizing a database, but it will not be able to generate a RAG prompt. The system will display
a warning if you attempt to use a RAG prompt without a document that has been vectorized.
"""
    st.markdown(details)

# st.write(description)
junk = \
"""
- The prompt screen contains pre-defined prompts that you can select from when asking questions to the LLM. You are also able to add more prompts to the system on this screen.
- The Q&A tab provides the interface to ask questions to the LLM. This screen provides options for what document to use for the RAG generation, along with parameters that adjust the text that the RAG process createes.
"""
# Document List

st.header("Document list",divider=True)
description = '''
The current collection of documents that are stored in watsonx.data are found in the list below. Select the document(s) that you want vectorized and press the Vectorize button. Note that you must load a document into Milvus before attempting to do a RAG prompt.
'''    

st.write(description)

with st.form("getDocument", clear_on_submit=False):
    details = db.runSQL(connection,"select id, document, type from iceberg_data.documents.metadata order by id asc")
    document_names = details['document'].tolist()
    document_ids   = details['id'].tolist()

    col1, col2 = st.columns([0.2,0.8])
    with col1:
        submitted = st.form_submit_button("Vectorize Document")
    with col2:
        ids = st.multiselect("Documents",document_ids,label_visibility="collapsed",format_func=lambda x: document_names[x-1],placeholder="Select documents")

    if (submitted and len(ids) == 0):
        st.error("You need to supply at least one document to vectorize!")
    elif (submitted and len(ids) > 0):
        collection = wxd_milvus.loadVectors(connection, ids)
        if (collection in [None,""]):
            sts.vectorized = False
            st.error("Error in vectorizing the document. Check the log for details.")
        sts.collection = collection
        sts.vectorized = True
    else:
        pass
